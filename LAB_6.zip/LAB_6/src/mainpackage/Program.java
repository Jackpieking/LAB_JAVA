package mainpackage;

import mainprogram.Start;

public final class Program
{
    public static void main(String[] args)
    {
        new Start().startMainProgram();
    }
}
