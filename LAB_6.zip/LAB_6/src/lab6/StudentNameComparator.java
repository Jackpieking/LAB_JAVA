package lab6;

import java.util.Comparator;

public class StudentNameComparator implements Comparator<Student>
{
    @Override
    public int compare(Student student1, Student student2)
    {
        return student1.get_name().compareTo(student2.get_name());
    }
}
