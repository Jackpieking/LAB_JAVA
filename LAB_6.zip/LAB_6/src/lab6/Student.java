package lab6;

import MostUse.Object;

import java.util.List;

public class Student
{
    private String _name;
    private String _class;
    private Float _mark;

    public Student(String _name, String _class, Float _mark)
    {
        this._name = _name;
        this._class = _class;
        this._mark = _mark;
    }

    public Student()
    {
        System.out.println("Please input student information");
        input();
    }

    String get_name()
    {
        return _name;
    }

    void input()
    {
        System.out.print("Name: ");
        _name = Object.sc.nextLine();

        System.out.print("Classes: ");
        _class  = Object.sc.nextLine();

        System.out.print("Mark: ");

        _mark = Object.sc.nextFloat();
        Object.sc.nextLine();
    }

    @Override
    public String toString()
    {
        return "Name: " + _name + "\n" +
                "Classes: " + _class + "\n" +
                "Mark: " + _mark;
    }
}
