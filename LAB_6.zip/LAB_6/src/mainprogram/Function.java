package mainprogram;

import MostUse.Object;
import lab6.Student;
import lab6.StudentNameComparator;

import java.util.List;

class Function
{
    static boolean confirmStudentCreationMethod()
    {
        while (true)
        {
            System.out.print("Do you want to enter more student information?(Y/N): ");
            switch (Object.sc.nextLine())
            {
                case "Y" -> {
                    return true;
                }
                case "N" -> {
                    return false;
                }
                default -> System.out.printf("%nInvalid input%n%n");
            }
        }
    }

    static void printStudentList(List<Student> students)
    {
        students.sort(new StudentNameComparator());

        for (int idx = 0; idx < students.size(); idx++)
        {
            System.out.printf("-------------Student %d-------------%n", idx + 1);
            System.out.println(students.get(idx));
        }
    }
}
