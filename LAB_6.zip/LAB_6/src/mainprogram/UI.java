package mainprogram;

class UI
{
    static void printMainUi()
    {
        System.out.println("====== Collection Sort Program ======");
    }
}
