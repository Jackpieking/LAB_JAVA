package mainprogram;

import lab6.Student;

import java.util.ArrayList;
import java.util.List;

public class Start
{
    private final List<Student> students = new ArrayList<>();

    public void startMainProgram()
    {
        UI.printMainUi();

        do
        {
            students.add(new Student());

        } while(Function.confirmStudentCreationMethod());

        System.out.println();

        Function.printStudentList(students);
    }
}
