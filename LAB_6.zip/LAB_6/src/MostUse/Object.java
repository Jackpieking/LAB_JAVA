package MostUse;

import java.util.Scanner;

public interface Object
{
    Scanner sc = new Scanner(System.in);
}
