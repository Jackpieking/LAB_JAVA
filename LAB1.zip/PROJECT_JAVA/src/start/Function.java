package start;

import mostuse.Method;
import mostuse.object;

import java.util.stream.IntStream;

class Function
{
    private Integer rows;
    private Integer cols;

    public void exercise1()
    {
        //input number of row
        rows = Method.inputIntegerInputAndValidate("Enter number of row");

        //input number of column
        cols = Method.inputIntegerInputAndValidate("Enter number of column");

        //print number of row
        System.out.println("Number of row: " + rows);

        //print number of column
        System.out.println("Number of column: " + cols);
    }

    public void exercise2()
    {
        Integer[][] _2DArray;

        //input rows and column
        exercise1();

        //create a 2D array
        _2DArray = new Integer[rows][cols];

        //initialize a 2D array
        IntStream.range(0, rows).forEach(row ->
        {
            IntStream.range(0, cols).forEach(col ->
            {
                System.out.printf("Enter matrix [%d][%d]: ", row, col);
                _2DArray[row][col] = object.sc.nextInt();
            });
        });

        //print out whole matrix
        System.out.println("The matrix:");

        IntStream.range(0, rows).forEach(row ->
        {
            IntStream.range(0, cols).forEach(col -> System.out.printf("%3d ", _2DArray[row][col]));
            System.out.println();
        });
    }
}
