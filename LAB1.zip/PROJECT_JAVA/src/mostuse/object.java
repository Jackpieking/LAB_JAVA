package mostuse;

import java.util.Scanner;

public interface object
{
    Scanner sc = new Scanner(System.in);
}
