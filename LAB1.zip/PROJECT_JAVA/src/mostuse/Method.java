package mostuse;

import java.util.regex.Pattern;

public class Method
{
    //input and validate string input
    public static String inputStringInputAndValidate(String title, String pattern)
    {
        String inputString;

        while (true)
        {
            System.out.printf("%s: ", title);
            inputString = object.sc.nextLine();

            if (Pattern.matches(pattern, inputString))
            {
                return inputString;
            }
            else
            {
                System.out.printf("%nInvalid string input%n%n");
            }
        }
    }

    //input and validate integer input
    public static int inputIntegerInputAndValidate(String title)
    {
        while (true)
        {
            System.out.printf("%s: ", title);

            if (object.sc.hasNextInt())
            {
                return object.sc.nextInt();
            }
            else
            {
                System.out.printf("%nInvalid positive integer input%n%n");
                object.sc.next();
            }
        }
    }
}
