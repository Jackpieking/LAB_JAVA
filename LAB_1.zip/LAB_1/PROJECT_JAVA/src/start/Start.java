package start;

public class Start
{
    public void start()
    {
        Function start = new Function();

        System.out.println("Exercise 1:");
        start.exercise1();

        System.out.printf("%nExercise 2:%n");
        start.exercise2();
    }
}
