package mainpackage;

import start.Start;

public final class Program
{
    public static void main(String[] args)
    {
        new Start().start();
    }
}
