package start;

import people.Doctor;

import java.util.List;

class Function
{
    void addDoctorFunc(List<Doctor> doctors)
    {
        System.out.printf("%n--------- Add Doctor ----------%n");

        doctors.add(new Doctor());

        System.out.println();
    }

    void viewListDoctorFunc(List<Doctor> doctors)
    {
        if (doctors.isEmpty())
        {
            System.out.printf("%nList of doctors is empty!!%n");
        }
        else
        {
            System.out.printf("%n%-10s%-10s%-30s%-30s%n",
                    "Code",
                    "Name",
                    "Specialization",
                    "Availability");

            doctors.forEach(System.out::println);
        }

        System.out.println();
    }

    void exit()
    {
        System.exit(1);
    }
}
