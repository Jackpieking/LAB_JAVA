package start;

import mostuse.*;
import people.Doctor;

import java.util.ArrayList;
import java.util.List;

public class Start
{
    static List<Doctor> doctors = new ArrayList<>();

    public void start()
    {
        UI uiPrinter = new UI();
        Function function = new Function();

        while (true)
        {
            uiPrinter.printMenu();

            switch (MUMethod.inputIntegerInputAndValidate("your choice"))
            {
                case 1 -> function.addDoctorFunc(doctors);
                case 2 -> function.viewListDoctorFunc(doctors);
                case 3 -> function.exit();
                default -> System.out.printf("%nOption not found!!%n%n");
            }
        }
    }
}
