package start;

class UI
{
    void printMenu()
    {
        System.out.println("========= Doctor Management ==========");
        System.out.println("1. Add doctor");
        System.out.println("2. View list doctor");
        System.out.println("3. Exit");
    }
}
