package people;

import mostuse.*;

public class Doctor
{
    private String code;
    private String name;
    private String specialization;
    private Integer availability;

    public Doctor()
    {
        setCode(MUMethod.inputStringInputAndValidate("code", MUObject.doctorCodeRegex));
        setName(MUMethod.inputStringInputAndValidate("name", MUObject.nameRegex));
        setSpecialization(MUMethod.inputStringInputAndValidate("specialization", MUObject.specializationRegex));
        setAvailability(MUMethod.inputIntegerInputAndValidate("availability"));
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public void setName(String name)
    {
        name = name.toLowerCase();
        name = name.substring(0, 1).toUpperCase().concat(name.substring(1));

        this.name = name;
    }

    public void setSpecialization(String specialization)
    {
        specialization = specialization.toLowerCase();
        specialization = specialization.substring(0, 1).toUpperCase().concat(specialization.substring(1));

        this.specialization = specialization;
    }

    public void setAvailability(Integer availability)
    {
        while (true)
        {
            if (availability > 0)
            {
                this.availability = availability;
                return;
            }

            System.out.printf("Availability cannot be negative, please input again!!%n%n");
            availability = MUMethod.inputIntegerInputAndValidate("availability");
        }
    }

    @Override
    public String toString()
    {
        return String.format("%-10s%-10s%-30s%-30d",
                code,
                name,
                specialization,
                availability);
    }
}
