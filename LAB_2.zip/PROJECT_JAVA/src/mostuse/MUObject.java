package mostuse;

import java.util.Scanner;

public interface MUObject
{
    Scanner sc = new Scanner(System.in);

    //regex
    String doctorCodeRegex = "^(DOC )([1-9]+)$";
    String nameRegex = "^[A-z]{2,}$";
    String specializationRegex = "^[A-z]{2,}$";
}
