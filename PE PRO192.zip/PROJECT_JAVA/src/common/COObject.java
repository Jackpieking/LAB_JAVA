package common;

import java.util.Scanner;

public interface COObject
{
    //input from keyboard
    Scanner sc = new Scanner(System.in);

    //regex
    String codeRegex = "^([A-Za-z])([1-9]+)$";
    String nameRegex = "^[A-Za-z ]+$";
}
