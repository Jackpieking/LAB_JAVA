package common;

import java.util.regex.Pattern;

public class COMethod
{
    public static String inputAndValidateStringInput(String title, String regex)
    {
        String input;

        while (true)
        {
            System.out.printf("Enter %s: ", title);
            input = COObject.sc.nextLine();

            if (Pattern.matches(regex, input))
            {
                return input;
            }

            System.out.printf("%nInvalid %s!!%n%n", title);
        }
    }
}
