package exercise1;

import common.COObject;

import java.math.BigInteger;

public class Program
{
    public static void main(String[] args)
    {
        BigInteger n;

        //input n
        System.out.print("Enter n: ");

        n = COObject.sc.nextBigInteger();
        COObject.sc.nextLine();

        System.out.printf("The sum of even number less than %d: %d", n, sumOfAllEvenNumber(n));
    }

    static BigInteger sumOfAllEvenNumber(BigInteger n)
    {
        BigInteger sum = BigInteger.ZERO;

        //sum of all even number
        for (BigInteger num = BigInteger.TWO; num.compareTo(n) < 0 ;num = num.add(BigInteger.ONE))
        {
            if (num.mod(BigInteger.TWO).equals(BigInteger.ZERO))
            {
                sum = sum.add(num);
            }
        }

        return sum;
    }
}