package exercise2.service;

import common.COObject;
import exercise2.model.Item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Function
{
    public void createItemFunc(ArrayList<Item> items)
    {
        System.out.printf("%n--------- Create Item ---------%n");

        items.add(new Item(items));

        System.out.printf("%nCreate successful!%n%n");
    }

    public void viewItemFunc(ArrayList<Item> items)
    {
        if (items.isEmpty())
        {
            System.out.printf("%nItem list is empty!!%n%n");
            return;
        }

        System.out.printf("%n--------------------Items Information-----------------------%n");
        System.out.printf("%-7s%-25s%s%n"
                , "Code"
                , "Name"
                , "Price");
        items.forEach(System.out::println);

        System.out.println();
    }

    public void  searchItemFunc(ArrayList<Item> items)
    {
        if (items.isEmpty())
        {
            System.out.printf("%nItem list is empty!!%n%n");
            return;
        }

        String code;

        System.out.printf("%n------- Search --------%n");
        System.out.print("Enter Code: ");
        code = COObject.sc.nextLine();

        var itemCodeList = items.stream().map(Item::getCode).sorted().toList();

        var itemIdx = Collections.binarySearch(itemCodeList, code, Comparator.naturalOrder());

        if (itemIdx < 0)
        {
            System.out.printf("not found%n");
        }
        else
        {
            Item foundItem = items.get(itemIdx);

            System.out.printf("%s | %s | %d%n"
                    , foundItem.getCode()
                    , foundItem.getName()
                    , foundItem.getPrice());
        }

        System.out.println();
    }

    public void exitFunc()
    {
        //exit program
        System.exit(0);
    }
}
