package exercise2.model;

import common.COMethod;
import common.COObject;

import java.util.ArrayList;
import java.util.Arrays;

public class Item
{
    private String code;
    private String name;
    private Integer price;

    public Item(ArrayList<Item> items)
    {
        setCode(items);
        setName();
        setPrice();
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(ArrayList<Item> items)
    {
        boolean existCode = false;

        while (true)
        {
            var codeInput = COMethod.inputAndValidateStringInput("Code", COObject.codeRegex).toLowerCase().toCharArray();
            codeInput[0] = Character.toUpperCase(codeInput[0]);

            code = String.valueOf(codeInput);

            if (items.isEmpty())
            {
                return;
            }

            for (Item item: items)
            {
                if (code.equals(item.code))
                {
                    System.out.printf("%nExist Item Code!!%n%n");
                    existCode = true;
                    break;
                }
            }

            if (!existCode)
            {
                return;
            }
        }
    }

    public String getName()
    {
        return name;
    }

    public void setName()
    {
        var nameInput = COMethod.inputAndValidateStringInput("Name", COObject.nameRegex).toLowerCase().toCharArray();
        nameInput[0] = Character.toUpperCase(nameInput[0]);

        name = String.valueOf(nameInput);
    }

    public Integer getPrice()
    {
        return price;
    }

    public void setPrice()
    {
        while (true)
        {
            System.out.print("Enter Price: ");

            if (COObject.sc.hasNextInt())
            {
                price = COObject.sc.nextInt();
                COObject.sc.nextLine();

                if (price > 0)
                {
                    return;
                }

                System.out.printf("%nPrice must be positive%n%n");
            }
            else
            {
                System.out.printf("%nInvalid price%n%n");
                COObject.sc.next();
            }
        }
    }

    @Override
    public String toString()
    {
        return String.format("%-7s%-25s%d"
                , code
                , name
                , price);
    }
}
