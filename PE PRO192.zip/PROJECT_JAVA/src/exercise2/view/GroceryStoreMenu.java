package exercise2.view;

public class GroceryStoreMenu
{
    public void UIPrinter()
    {
        System.out.println("WELCOME TO ITEM MANAGEMENT");
        System.out.printf("%21s%n", "1. Create item");
        System.out.printf("%20s%n", "2. View item ");
        System.out.printf("%22s%n", "3. Search item ");
        System.out.printf("%14s%n%n", "4. Exit");
        System.out.printf("%50s%n", "(Please choose 1 to Create, 2 to View, 3 to Search, 4 Exit)");
    }
}
