package exercise2;

import exercise2.presenter.Start;

public class Program
{
    public static void main(String[] args)
    {
        new Start().startGroceryStoreManagementProgram();
    }
}