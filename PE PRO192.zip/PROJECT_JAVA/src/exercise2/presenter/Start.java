package exercise2.presenter;

import common.COObject;
import exercise2.model.Item;
import exercise2.service.Function;
import exercise2.view.GroceryStoreMenu;

import java.util.ArrayList;

public class Start
{
    private ArrayList<Item> items = new ArrayList<>();

    public void startGroceryStoreManagementProgram()
    {
        GroceryStoreMenu groceryStoreMenuObj = new GroceryStoreMenu();
        Function functionObj = new Function();

        while (true)
        {
            //print grocery store menu
            groceryStoreMenuObj.UIPrinter();

            //input choice value and validate value
            System.out.printf("%nEnter choice: ");
            switch (COObject.sc.nextLine())
            {
                //create a new item
                case "1":
                {
                    functionObj.createItemFunc(items);
                    break;
                }

                //view all item
                case "2":
                {
                    functionObj.viewItemFunc(items);
                    break;
                }

                //search a specific item
                case "3":
                {
                    functionObj.searchItemFunc(items);
                    break;
                }

                //exit program
                case "4":
                {
                    functionObj.exitFunc();
                    break;
                }

                //choice is not found
                default:
                {
                    System.out.printf("%nChoice not found%n%n");
                }
            }
        }
    }
}
