import java.util.Random;
import java.util.Scanner;

public interface MostUseObject
{
    Scanner sc = new Scanner(System.in);
    Random random = new Random();
}
