import java.util.ArrayList;

public final class Program
{
    public static void main(String[] args)
    {
        bai2();
    }

    static void bai2()
    {
        int fractionCounts;
        ArrayList<Fraction> fractions = new ArrayList<>();

        //print the user menu
        FractionControlUserInterface.printMenu();

        //get the number of fractions from user
        try
        {
            fractionCounts = MainProgramControl.getNumberOfFractions();

            if (fractionCounts == 0)
            {
                throw new ArrayStoreException("List size cannot be empty");
            }

            if (fractionCounts < 0)
            {
                throw new ArrayStoreException("List size cannot be negative");
            }

            //fill the fractions with random fraction
            MainProgramControl.inputFractions(fractions, fractionCounts);

            //sort the Fractions list
            MainProgramControl.sortFractionList(fractions);

            //print out the whole list
            System.out.println("Sorted fraction list:");
            System.out.println(fractions);
        }
        catch(ArrayStoreException ASe)
        {
            System.out.printf("%n%s%n", ASe.getMessage());
        }
    }
}
