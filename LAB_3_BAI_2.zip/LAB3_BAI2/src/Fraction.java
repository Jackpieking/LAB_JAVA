import java.util.StringJoiner;

public class Fraction implements Comparable<Fraction>
{
    private Integer numerator;
    private Integer denominator;

    //initialize a new fraction
    public Fraction(Integer numerator, Integer denominator)
    {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    //get the numerator of the fraction
    public Integer getNumerator()
    {
        return numerator;
    }

    //set the numerator of the fraction
    public void setNumerator(Integer numerator)
    {
        this.numerator = numerator;
    }

    //get the denominator of the fraction
    public Integer getDenominator()
    {
        return denominator;
    }

    //get the denominator of the fraction
    public void setDenominator(Integer denominator)
    {
        this.denominator = denominator;
    }

    //comparator sorting the fraction increasingly by numerator
    @Override
    public int compareTo(Fraction fraction)
    {
        return getNumerator().compareTo(fraction.getNumerator());
    }

    //a string displaying the
    @Override
    public String toString()
    {
        return new StringJoiner(", ")
                .add(numerator + "/" + denominator)
                .toString();
    }
}
