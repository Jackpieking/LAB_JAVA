public class FractionControlUserInterface
{
    //display user main menu
    public static void printMenu()
    {
        System.out.println("Enter the number of list:");
    }

}
