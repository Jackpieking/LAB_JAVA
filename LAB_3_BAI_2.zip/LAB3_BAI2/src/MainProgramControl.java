import java.math.BigInteger;
import java.util.ArrayList;

public class MainProgramControl
{
    //input the number of fractions from user
    public static Integer getNumberOfFractions()
    {
        while (true)
        {
            if (MostUseObject.sc.hasNextInt())
            {
                return MostUseObject.sc.nextInt();
            } else
            {
                System.out.printf("%nInvalid input%n%n");
                MostUseObject.sc.next();
            }
        }
    }

    public static void inputFractions(ArrayList<Fraction> fractions, Integer fractionCounts)
    {
        for (int idx = 0; idx < fractionCounts; idx++)
        {
            fractions.add(new Fraction(MostUseObject.random.nextInt(1, 20), MostUseObject.random.nextInt(1, 20)));
        }
    }

    public static void sortFractionList(ArrayList<Fraction> fractions)
    {
        var anonyObj = new Object()
        {
            Integer maxDominator = 1;
            BigInteger gcdAns;
        };

        //sort the fraction list by denominator
        fractions.sort((fraction1, fraction2) ->
                fraction2.getDenominator().compareTo(fraction1.getDenominator()));

        //get the largest denominator
        anonyObj.maxDominator = fractions.get(0).getDenominator();

        if (fractions.stream().allMatch(fraction ->
                anonyObj.maxDominator % fraction.getDenominator().compareTo(0) == 0))
        {
            Fraction newFraction;

            for (int idx = 1; idx < fractions.size(); idx++)
            {
                newFraction = fractions.get(idx);

                newFraction.setDenominator(anonyObj.maxDominator);
                newFraction.setNumerator(newFraction.getNumerator() * anonyObj.maxDominator / newFraction.getDenominator());
            }
        } else
        {
            var commonDivisor = new Object()
            {
                Integer val = 1;
            };

            fractions.forEach(fraction ->
                    commonDivisor.val *= fraction.getDenominator());

            fractions.forEach(fraction ->
            {
                fraction.setNumerator(fraction.getNumerator() * (commonDivisor.val / fraction.getDenominator()));
                fraction.setDenominator(commonDivisor.val);
            });
        }

        fractions.sort(Fraction::compareTo);

        fractions.forEach(fraction ->
        {
            anonyObj.gcdAns = BigInteger.valueOf(fraction.getNumerator()).gcd(BigInteger.valueOf(fraction.getDenominator()));
            fraction.setNumerator(fraction.getNumerator() / anonyObj.gcdAns.intValue());
            fraction.setDenominator(fraction.getDenominator() / anonyObj.gcdAns.intValue());
        });
    }
}