package lab5bai2;

import MostUse.MostUseObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

public class Bai2
{
    public static void CountWords()
    {
        String word;
        int count = 0;

        System.out.println("Enter word: ");
        word = MostUseObject.sc.nextLine();

        var res = Arrays.stream(word.trim().split(" ")).toList();

        Set<String> distinctWord = new HashSet<>(res);

        Hashtable<String, Integer> table = new Hashtable<>();

        for (var singleWord : distinctWord)
        {
            for (var wordInWord : res)
            {
                if (singleWord.equals(wordInWord))
                {
                    count++;
                }
            }

            table.put(singleWord, count);
            count = 0;
        }

        System.out.println(table);
    }
}
