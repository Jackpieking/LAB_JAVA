package MostUse;

public class MostUseMethod
{
    public static String inputString(String title)
    {
        String input;

        while (true)
        {
            System.out.printf("%s: ", title);
            input = MostUseObject.sc.nextLine();

            if (input.isBlank())
            {
                System.out.printf("%n%s cannot be blank !!%n%n", title);
            }
            else
            {
                return input.trim();
            }
        }
    }
}
