package MostUse;

import java.util.Scanner;

public interface MostUseObject
{
    Scanner sc = new Scanner(System.in);
}
