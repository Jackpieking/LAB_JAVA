package mainpackage;

import lab5.StudentManagementCenter;
import lab5bai2.Bai2;

public final class Program
{
    public static void main(String[] args)
    {
        //StudentManagementCenter.Start();
        Bai2.CountWords();
    }
}
