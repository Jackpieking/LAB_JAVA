package lab5;

import MostUse.MostUseObject;

import java.util.Collections;

final class StudentManagementFunction
{
    static void create()
    {
        StudentManagementCenter.students.add(Student.input());

        System.out.println();
    }

    static void  viewAllStudentInformation()
    {
        if (StudentManagementCenter.students.isEmpty())
        {
            System.out.printf("%nStudent List is empty !!%n");
        }
        else
        {
            System.out.printf("%n--- Students information ---%n");

            StudentManagementCenter.students.forEach(System.out::println);
        }

        System.out.println();
    }

    static void search()
    {
        String inputId;
        int searchRes;

        while (true)
        {
            System.out.printf("%nEnter student id: ");
            inputId = MostUseObject.sc.nextLine();

            if (inputId.isBlank())
            {
                System.out.printf("%nStudent id cannot be blank !!%n%n");
            }
            else
            {
                inputId = inputId.trim();

                break;
            }
        }

        StudentManagementCenter.students.sort(new Student());

        searchRes = Collections.binarySearch(StudentManagementCenter.students, new Student(inputId), new Student());

        if (searchRes >= 0)
        {
            System.out.println(StudentManagementCenter.students.get(searchRes));
        }
        else
        {
            System.out.printf("%nId is not found%n%n");
        }
    }

    static void exit()
    {
        System.exit(0);
    }
}
