package lab5;

import MostUse.MostUseMethod;
import MostUse.MostUseObject;

import java.util.Comparator;
import java.util.StringJoiner;

final class Student implements Comparator<Student>
{
    private String id;
    private String name;
    private String address;
    private String phone;

    public Student(String id)
    {
        this.id = id;
    }

    public Student()
    {

    }

    static Student input()
    {
        var newStudent = new Student();

        System.out.printf("%nStudent:%n");

        while (true)
        {
            System.out.print("Id: ");
            newStudent.id = MostUseObject.sc.nextLine();

            if (StudentManagementCenter.students
                    .stream()
                    .anyMatch(student -> student.id.equals(newStudent.id)))
            {
                System.out.printf("%nId has existed !!%n%n");
            }
            else
            {
                break;
            }
        }

        newStudent.name = MostUseMethod.inputString("Name");

        newStudent.address = MostUseMethod.inputString("Address");

        newStudent.phone = MostUseMethod.inputString("Phone");

        return newStudent;
    }

    @Override
    public String toString()
    {
        return new StringJoiner(", ", "[", "]")
                .add("id = "+ id)
                .add("name = " + name)
                .add("address = " + address)
                .add("phone = " + phone)
                .toString();
    }

    @Override
    public int compare(Student student1, Student student2)
    {
        return student1.id.compareTo(student2.id);
    }
}
