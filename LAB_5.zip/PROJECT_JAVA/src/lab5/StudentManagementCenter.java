package lab5;

import MostUse.MostUseObject;

import java.util.ArrayList;
import java.util.List;

public class StudentManagementCenter
{
    static final List<Student> students = new ArrayList<>();

    public static void Start()
    {
        while (true)
        {
            StudentManagementMenu.menuPrinting();

            switch (MostUseObject.sc.nextLine())
            {
                case "1" -> StudentManagementFunction.create();
                case "2" -> StudentManagementFunction.viewAllStudentInformation();
                case "3" -> StudentManagementFunction.search();
                case "4" -> StudentManagementFunction.exit();
            }
        }
    }
}
