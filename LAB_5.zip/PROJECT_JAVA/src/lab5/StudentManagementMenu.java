package lab5;

final class StudentManagementMenu
{
    static void menuPrinting()
    {
        System.out.println("WELCOME TO STUDENT MANAGEMENT");
        System.out.printf("%16s%n", "1. Create");
        System.out.printf("%38s%n", "2. View all student information");
        System.out.printf("%16s%n", "3. Search");
        System.out.printf("%14s%n", "4. Exit");
        System.out.print("Enter your choice: ");
    }
}
