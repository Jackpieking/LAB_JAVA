package person;

import mostuse.MostUseMethod;
import mostuse.MostUseObject;

import java.util.List;

public class Doctor extends Employee
{
    private Integer level;
    private String major;
    private Integer positionAllowance;

    //-----------------------------------------------------
    //get doctor level
    public Integer getLevel()
    {
        return level;
    }

    //get doctor position allowance
    public Integer getPositionAllowance()
    {
        return positionAllowance;
    }

    //input doctor all related information
    @Override
    public void inputEmployee(List<Employee> employees)
    {
        System.out.printf("Doctor:%n");

        setEmployeeType("1");

        super.inputEmployee(employees);

        //input and validate level
        level = MostUseMethod.integerInputAndValidate("level");

        //input and validate major
        major = MostUseMethod.stringInputAndValidate("major", MostUseObject.doctorMajorRegex);

        //input and validate position allowance
        positionAllowance = MostUseMethod.integerInputAndValidate("position allowance");
    }

    @Override
    //print doctor all related information
    public void printEmployee()
    {
        super.printEmployee();

        System.out.printf(" |%-8d |%-15s |%-21d |%n",
                level,
                major,
                positionAllowance);
    }
}
