package person;

import mostuse.MostUseMethod;
import mostuse.MostUseObject;

import java.util.List;

public class Nurse extends Employee
{
    private String department;
    private Integer overtimeHours;

    //-----------------------------------------------------
    //get nurse overtime hours
    public Integer getOvertimeHours()
    {
        return overtimeHours;
    }

    //input nurse all related information
    @Override
    public void inputEmployee(List<Employee> employees)
    {
        System.out.printf("Nurse:%n");

        setEmployeeType("2");

        super.inputEmployee(employees);

        //input and validate department
        department = MostUseMethod.stringInputAndValidate("department", MostUseObject.nurseDepartmentRegex);

        //input and validate overtime hours
        overtimeHours = MostUseMethod.integerInputAndValidate("overtime hours");
    }

    //print nurse all related information
    @Override
    public void printEmployee()
    {
        super.printEmployee();

        System.out.printf(" |%-15s |%-21d |%n",
                department,
                overtimeHours);
    }
}
