package person;

import mostuse.MostUseMethod;
import mostuse.MostUseObject;

import java.util.List;

public class Employee
{
    //employee fields
    private String id;
    private String name;
    private String phone;
    private String email;
    private Float coefficientsSalary;
    private String employeeType;

    //-----------------------------------------------------
    //get the employee type
    public String getEmployeeType()
    {
        return employeeType;
    }

    public String getName()
    {
        return name;
    }

    public Float getCoefficientsSalary()
    {
        return coefficientsSalary;
    }

    //set the employee type
    public void setEmployeeType(String employeeType)
    {
        this.employeeType = employeeType;
    }

    //input and validate id
    void setId(List<Employee> employees)
    {
        while (true)
        {
            if (employeeType.equals("1"))
            {
                id = MostUseMethod.stringInputAndValidate("doctor id(D1, D2,....)", MostUseObject.doctorIdDRegex);
            } else
            {
                id = MostUseMethod.stringInputAndValidate("nurse id(N1, N2,....)", MostUseObject.nurseIdRegex);
            }

            if (employees.isEmpty())
            {
                break;
            }

            if (employees.stream().allMatch(employee -> employee.id.equals(id)))
            {
                System.out.printf("%nExisted id, please input again !!%n%n");
            } else
            {
                break;
            }
        }
    }

    //input and validate name
    public void setName()
    {
        name = MostUseMethod.stringInputAndValidate("name", MostUseObject.nameRegex);
    }

    //input and validate phone
    void setPhone(List<Employee> employees)
    {
        while (true)
        {
            phone = MostUseMethod.stringInputAndValidate("phone", MostUseObject.phoneNumberRegex);

            if (employees.isEmpty())
            {
                break;
            }

            if (employees.stream().allMatch(employee -> employee.phone.equals(phone)))
            {
                System.out.printf("%nExisted phone number, please input again !!%n%n");
            } else
            {
                break;
            }
        }
    }

    //input and validate email
    void setEmail(List<Employee> employees)
    {
        while (true)
        {
            email = MostUseMethod.stringInputAndValidate("email", MostUseObject.emailRegex);

            if (employees.isEmpty())
            {
                break;
            }

            if (employees.stream().allMatch(employee -> employee.email.equals(email)))
            {
                System.out.printf("%nExisted email, please input again !!%n%n");
            } else
            {
                break;
            }
        }
    }

    //input and validate coefficients salary
    void setCoefficientsSalary()
    {
        coefficientsSalary = MostUseMethod.floatInputAndValidate("coefficients salary");
    }

    //input employee all related information
    void inputEmployee(List<Employee> employees)
    {
        setId(employees);
        setName();
        setPhone(employees);
        setEmail(employees);
        setCoefficientsSalary();
    }

    //print employee all related information
    void printEmployee()
    {
        System.out.printf("|%-6s |%-25s |%-12s |%-30s |%-18.2f",
                id,
                name,
                phone,
                email,
                coefficientsSalary);
    }
}
