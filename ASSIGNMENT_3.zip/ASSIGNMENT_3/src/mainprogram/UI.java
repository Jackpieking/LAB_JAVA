package mainprogram;

class UI
{
    //employee management menu
    static void employeeManagementMenu()
    {
        System.out.println("WELCOME TO EMPLOYEE MANAGEMENT");
        System.out.printf("%17s%n", "1. Create");
        System.out.printf("%40s%n", "2. View all employee information");
        System.out.printf("%71s%n", "3. View the employee's information has the highest total salary");
        System.out.printf("%20s%n", "4. Searching");
        System.out.printf("%15s%n", "5. Exit");
        System.out.printf("""
                (Please choose 1 to Create employee, 2 to view all employee information, 3 to view the\s
                employee's information has the highest total salary, 4 to search employee information, 5 to\s
                exit)%n%n""");
    }
}
