package mainprogram;

import mostuse.MostUseMethod;
import person.Employee;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class Start
{
    private final List<Employee> employees = new ArrayList<>();

    public void start()
    {
        while (true)
        {
            System.gc();

            UI.employeeManagementMenu();

            switch (MostUseMethod.integerInputAndValidate("choice"))
            {
                case 1 -> Function.createEmployee(employees);
                case 2 -> Function.viewAllEmployeeInformation(employees);
                case 3 -> Function.viewTheEmployeeInformationHasTheHighestSalary(employees);
                case 4 -> Function.searchEmployee(employees);
                case 5 -> Function.exit();
                default -> System.out.printf("%nChoice is not matched%n%n");
            }
        }
    }
}
