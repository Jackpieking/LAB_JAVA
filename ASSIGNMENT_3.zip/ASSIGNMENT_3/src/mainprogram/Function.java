package mainprogram;

import mostuse.MostUseMethod;
import mostuse.MostUseObject;
import mostuse.SortEmployeeIncreasinglyById;
import person.Doctor;
import person.Employee;
import person.Nurse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Function
{
    //adding a new employee to the list
    static void createEmployee(List<Employee> employees)
    {
        var chosenEmployeeType = chooseEmployeeType();

        if (checkForContinuing() == 0)
        {
            return;
        }

        //add a new doctor to the list
        if (chosenEmployeeType == 1)
        {
            var newDoctor = new Doctor();
            newDoctor.inputEmployee(employees);
            employees.add(newDoctor);

            System.out.printf("%nAdding new doctor successfully%n%n");
        }
        //add a new nurse to the list
        else
        {
            var newNurse = new Nurse();
            newNurse.inputEmployee(employees);
            employees.add(newNurse);

            System.out.printf("%nAdding new nurse successfully%n%n");
        }
    }

    //input and validate employee type
    static int chooseEmployeeType()
    {
        while (true)
        {
            System.out.printf("%nEmployee type:%n");
            System.out.println("1. Doctor");
            System.out.printf("2. Nurse%n%n");

            switch (MostUseMethod.integerInputAndValidate("employee type"))
            {
                case 1 -> {
                    return 1;
                }

                case 2 -> {
                    return 2;
                }

                default -> System.out.printf("%nEmployee type is not found%n");
            }
        }
    }

    //ask user to confirm whether to continue creating employee or not
    static int checkForContinuing()
    {
        System.out.printf("%nDo you want to continue (Y/N)?%n");
        System.out.println("Y");
        System.out.printf("N%n%n");

        while (true)
        {
            System.out.print("Enter choice: ");
            switch (MostUseObject.sc.nextLine())
            {
                case "Y" -> {
                    System.out.println();
                    return 1;
                }

                case "N" -> {
                    System.out.println();
                    return 0;
                }

                default -> System.out.printf("%nInvalid confirmation choice%n%n");
            }
        }
    }

    //-----------------------------------------------------
    //view all employee all related information
    static void viewAllEmployeeInformation(List<Employee> employees)
    {
        if (employees.isEmpty())
        {
            System.out.printf("%nNo employees are available%n%n");
            return;
        }

        employees.sort(new SortEmployeeIncreasinglyById());
        checkForDoctorExistenceAndPrintAllDoctorInformation(employees);
        checkForNurseExistenceAndPrintAllNurseInformation(employees);
    }

    //search for nurse existence
    static void checkForNurseExistenceAndPrintAllNurseInformation(List<Employee> employees)
    {
        if (employees.get(employees.size() - 1) instanceof Nurse)
        {
            printNurseAllRelatedInformation(employees);
        } else
        {
            System.out.printf("No nurses are found%n%n");
        }
    }

    //print nurse all related information
    static void printNurseAllRelatedInformation(List<Employee> employees)
    {
        System.out.println("+------------------------------------------------------------------- NURSE ------------------------------------------------------------------+");
        System.out.printf("|%-6s |%-25s |%-12s |%-30s |%-12s |%-15s |%-21s |%n",
                "ID",
                "NAME",
                "PHONE",
                "EMAIL",
                "COEFFICIENT SALARY",
                "DEPARTMENT",
                "OVERTIME HOURS");
        System.out.println("+--------------------------------------------------------------------------------------------------------------------------------------------+");

        for (int idx = employees.size() - 1; idx >= 0; idx--)
        {
            var employee = employees.get(idx);

            if (employee instanceof Nurse)
            {
                ((Nurse) employee).printEmployee();
            } else
            {
                break;
            }
        }

        System.out.println("+--------------------------------------------------------------------------------------------------------------------------------------------+");

        System.out.println();
    }

    //search for doctor existence
    static void checkForDoctorExistenceAndPrintAllDoctorInformation(List<Employee> employees)
    {
        System.out.println();

        if (employees.get(0) instanceof Doctor)
        {
            printDoctorAllRelatedInformation(employees);
        } else
        {
            System.out.printf("No doctors are found%n%n");
        }
    }

    //print doctor all related information
    static void printDoctorAllRelatedInformation(List<Employee> employees)
    {
        System.out.println("+----------------------------------------------------------------------- DOCTOR -----------------------------------------------------------------------+");
        System.out.printf("|%-6s |%-25s |%-12s |%-30s |%-12s |%-8s |%-15s |%-21s |%n",
                "ID",
                "NAME",
                "PHONE",
                "EMAIL",
                "COEFFICIENT SALARY",
                "LEVEL",
                "MAJOR",
                "POSITION ALLOWANCE");
        System.out.println("+------------------------------------------------------------------------------------------------------------------------------------------------------+");

        for (var employee : employees)
        {
            if (employee instanceof Doctor)
            {
                ((Doctor) employee).printEmployee();
            } else
            {
                break;
            }
        }

        System.out.println("+------------------------------------------------------------------------------------------------------------------------------------------------------+");

        System.out.println();
    }

    //-----------------------------------------------------
    //print out all employees having the highest salary
    static void viewTheEmployeeInformationHasTheHighestSalary(List<Employee> employees)
    {
        if (employees.isEmpty())
        {
            System.out.printf("%nNo employees are available%n%n");
            return;
        }

        List<Employee> employeeHavingHighestSalaryList = new ArrayList<>();
        List<Float> totalSalaryList = new ArrayList<>();

        employees.sort(new SortEmployeeIncreasinglyById());
        calculateTotalSalaryOfEmployees(totalSalaryList, employees);
        Collections.sort(totalSalaryList);
        findEmployeesHavingHighestTotalSalary(employeeHavingHighestSalaryList,
                totalSalaryList,
                employees);

        System.out.printf("%n---- EMPLOYEES HAVING HIGHEST SALARY ----%n");

        checkForDoctorExistenceAndPrintAllDoctorInformation(employeeHavingHighestSalaryList);
        checkForNurseExistenceAndPrintAllNurseInformation(employeeHavingHighestSalaryList);
    }

    //calculate the total salary of each employee
    static void calculateTotalSalaryOfEmployees(List<Float> totalSalaryList, List<Employee> employees)
    {
        for (Employee employee : employees)
        {
            if (employee instanceof Doctor doctor)
            {
                totalSalaryList.add(((doctor.getLevel() + doctor.getCoefficientsSalary()) * 1650000) + doctor.getPositionAllowance());
            } else
            {
                var nurse = (Nurse) employee;
                totalSalaryList.add((nurse.getCoefficientsSalary() * 1650000) + nurse.getOvertimeHours() * 200000);
            }
        }
    }

    //find the employees having the high total salary
    static void findEmployeesHavingHighestTotalSalary(List<Employee> employeeHavingHighestSalaryList
            , List<Float> totalSalaryList
            , List<Employee> employees)
    {
        float highestTotalSalary = totalSalaryList.get(totalSalaryList.size() - 1);

        for (int idx = 0; idx < employees.size(); idx++)
        {
            if (totalSalaryList.get(idx) == highestTotalSalary)
            {
                employeeHavingHighestSalaryList.add(employees.get(idx));
            }
        }
    }

    //-----------------------------------------------------
    //search the employee with given id and name
    static void searchEmployee(List<Employee> employees)
    {
        if (employees.isEmpty())
        {
            System.out.printf("%nNo employees are available%n%n");
            return;
        }

        String employeeType;
        String employeeName;

        System.out.printf("%nEnter employee type: ");
        employeeType = MostUseObject.sc.nextLine();

        employeeName = MostUseMethod.stringInputAndValidate("name", MostUseObject.nameRegex);

        searchEmployeeAndDisplayResult(employees, employeeType, employeeName);

        System.out.println();
    }

    //search the employee in the list and display the searching result
    static void searchEmployeeAndDisplayResult(List<Employee> employees,
            String employeeType,
            String employeeName)
    {
        int foundIndex;

        employees.sort(new SortEmployeeIncreasinglyById());
        foundIndex = employeeBinarySearch(employees, employeeName, employeeType);

        if (foundIndex >= 0)
        {
            System.out.printf("%nFound employee:%n%n");

            var employee = employees.get(foundIndex);

            if (employee instanceof Doctor)
            {
                System.out.println("+----------------------------------------------------------------------- DOCTOR -----------------------------------------------------------------------+");
                System.out.printf("|%-6s |%-25s |%-12s |%-30s |%-12s |%-8s |%-15s |%-21s |%n",
                        "ID",
                        "NAME",
                        "PHONE",
                        "EMAIL",
                        "COEFFICIENT SALARY",
                        "LEVEL",
                        "MAJOR",
                        "POSITION ALLOWANCE");
                System.out.println("+------------------------------------------------------------------------------------------------------------------------------------------------------+");

                ((Doctor) employee).printEmployee();

                System.out.println("+------------------------------------------------------------------------------------------------------------------------------------------------------+");
            } else
            {
                System.out.println("+------------------------------------------------------------------- NURSE ------------------------------------------------------------------+");
                System.out.printf("|%-6s |%-25s |%-12s |%-30s |%-12s |%-15s |%-21s |%n",
                        "ID",
                        "NAME",
                        "PHONE",
                        "EMAIL",
                        "COEFFICIENT SALARY",
                        "DEPARTMENT",
                        "OVERTIME HOURS");
                System.out.println("+--------------------------------------------------------------------------------------------------------------------------------------------+");

                ((Nurse) employee).printEmployee();

                System.out.println("+--------------------------------------------------------------------------------------------------------------------------------------------+");
            }
        } else
        {
            System.out.printf("%nNot found!%n");
        }
    }

    //search employee using given employee name and employee type
    static int employeeBinarySearch(List<Employee> employees,
            String employeeName,
            String employeeType)
    {
        int start = 0;
        int mid;
        int end = employees.size() - 1;

        while (start <= end)
        {
            mid = (start + end) / 2;

            if (employees.get(mid).getEmployeeType().equals(employeeType) &&
                    employees.get(mid).getName().equals(employeeName))
            {
                return mid;
            }

            if (employees.get(mid).getName().compareTo(employeeName) < 0)
            {
                end = mid - 1;
            } else
            {
                start = mid + 1;
            }
        }

        return -1;
    }

    //-----------------------------------------------------
    //exit the employee management program
    static void exit()
    {
        System.exit(0);
    }
}
