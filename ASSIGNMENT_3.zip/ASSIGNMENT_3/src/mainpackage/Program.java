package mainpackage;

import mainprogram.Start;

final class Program
{
    public static void main(String[] args)
    {
        //assignment 3 program starts here
        new Start().start();
    }
}
