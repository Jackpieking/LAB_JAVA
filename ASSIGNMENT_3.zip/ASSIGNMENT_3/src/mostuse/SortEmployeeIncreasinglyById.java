package mostuse;

import person.Employee;

import java.util.Comparator;

public class SortEmployeeIncreasinglyById implements Comparator<Employee>
{
    @Override
    public int compare(Employee employee1, Employee employee2)
    {
        return employee1.getEmployeeType().compareTo(employee2.getEmployeeType());
    }
}
