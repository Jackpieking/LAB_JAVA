package mostuse;

import java.util.regex.Pattern;

public class MostUseMethod
{
    //input string and validate the string by the pattern
    public static String stringInputAndValidate(String title, String pattern)
    {
        String keyboardInput;

        do
        {
            System.out.printf("Enter %s: ", title);
            keyboardInput = MostUseObject.sc.nextLine();

            if (Pattern.matches(pattern, keyboardInput))
            {
                return keyboardInput;
            }

            System.out.printf("%n%s is not matched the %s pattern%n%n", title, title);
        } while (true);
    }

    //input float number and validate the number
    public static Float floatInputAndValidate(String title)
    {
        float keyboardInput;

        do
        {
            System.out.printf("Enter %s: ", title);

            if (MostUseObject.sc.hasNextFloat())
            {
                keyboardInput = MostUseObject.sc.nextFloat();
                MostUseObject.sc.nextLine();

                return keyboardInput;
            }

            System.out.printf("%nInvalid %s%n%n", title);
            MostUseObject.sc.next();
        } while (true);
    }

    //input integer number and validate the number
    public static Integer integerInputAndValidate(String title)
    {
        int keyboardInput;

        do
        {
            System.out.printf("Enter %s: ", title);

            if (MostUseObject.sc.hasNextInt())
            {
                keyboardInput = MostUseObject.sc.nextInt();
                MostUseObject.sc.nextLine();

                return keyboardInput;
            }

            System.out.printf("%nInvalid %s%n%n", title);
            MostUseObject.sc.next();
        } while (true);
    }
}
