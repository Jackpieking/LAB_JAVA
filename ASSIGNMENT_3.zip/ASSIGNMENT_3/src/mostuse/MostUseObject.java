package mostuse;

import java.util.Scanner;

public interface MostUseObject
{
    //keyboard input stream
    Scanner sc = new Scanner(System.in);

    //field validation regex
    String doctorIdDRegex = "^[D]([1-9])+$";
    String nurseIdRegex = "^[N]([1-9])+$";
    String nameRegex = "^(([A-Z]([a-z])+)[ ])(([A-Z]([a-z])+)[ ])([A-Z]([a-z])+)([ ][A-Z]([a-z])+)?([ ][A-Z]([a-z])+)?$";
    String phoneNumberRegex = "^[0][1-9][0-9]{8}$";
    String emailRegex = "^((\\w)+([!#$%&'*+\\-\\/=?^_`{|}~])?)+[@](\\w){3,}[.](\\w){3,}([.](\\w){2,})?$";
    String doctorMajorRegex = "^([A-Z]([a-z])+)([ ]?([-])?([a-z])+)?([ ]([a-z])+)?([ ]([a-z])+)?([ ]([a-z])+)?$";
    String nurseDepartmentRegex = "^([A-Z]([a-z])+)([ ]?([-])?([a-z])+)?([ ]([a-z])+)?([ ]([a-z])+)?([ ]([a-z])+)?$";
}
