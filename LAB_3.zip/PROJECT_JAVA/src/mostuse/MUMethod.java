package mostuse;

import java.util.regex.Pattern;

public class MUMethod
{
    //input and validate string input
    public static String inputStringAndValidate(String title, String pattern)
    {
        String inputString;

        while (true)
        {
            System.out.printf("Enter %s: ", title);
            inputString = MUObject.sc.nextLine();

            if (Pattern.matches(pattern, inputString))
            {
                return inputString;
            }
            else
            {
                System.out.printf("%nInvalid %s input%n%n", title);
            }
        }
    }

    //input and validate integer input
    public static int inputIntegerAndValidate(String title)
    {
        int input;

        while (true)
        {
            System.out.printf("Enter %s: ", title);

            if (MUObject.sc.hasNextInt())
            {
                input = MUObject.sc.nextInt();
                MUObject.sc.nextLine();

                return input;
            }
            else
            {
                System.out.printf("%nInvalid %s%n%n", title);
                MUObject.sc.next();
            }
        }
    }

    //input and validate float input
    public static float inputFloatAndValidate(String title)
    {
        float input;

        while (true)
        {
            System.out.printf("Enter %s: ", title);

            if (MUObject.sc.hasNextFloat())
            {
                input = MUObject.sc.nextFloat();
                MUObject.sc.nextLine();

                return input;
            }
            else
            {
                System.out.printf("%nInvalid %s%n%n", title);
                MUObject.sc.next();
            }
        }
    }
}
