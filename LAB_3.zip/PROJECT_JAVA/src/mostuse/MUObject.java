package mostuse;

import java.util.Scanner;

public interface MUObject
{
    Scanner sc = new Scanner(System.in);

    //employee regex
    String nameRegex = "^([A-z]+)([ ]([A-z])+)?([ ])?$";
    String phoneRegex = "^[0]([1-9])[0-9]{8}([ ])?$";
    String emailRegex = "^([A-z]+[0-9]*)[@]([a-z]{3,})[.]([a-z]{3,})([ ])?$";

    //doctor regex
    String doctorIdRegex = "^L[1-9]+([ ])?$";

    //nurse regex
    String nurseIdRegex = "^O[1-9]+([ ])?$";
    String nurseDepartmentRegex = "^[A-z]+([ ])?$";
}
