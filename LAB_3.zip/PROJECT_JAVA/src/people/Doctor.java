package people;

import mostuse.MUMethod;
import mostuse.MUObject;

public class Doctor extends Employee
{
    private Float coefficient;

    public void setCoefficient(Float coefficient)
    {
        this.coefficient = coefficient;
    }

    @Override
    public void inputEmployeeInfo()
    {
        setEmployeeType(Byte.valueOf("0"));
        setId(MUMethod.inputStringAndValidate("doctor id", MUObject.doctorIdRegex));

        super.inputEmployeeInfo();

        setCoefficient(MUMethod.inputFloatAndValidate("coefficient salary"));
    }

    @Override
    public String toString()
    {
        return super.toString().concat(coefficient.toString());
    }
}
