package people;

import mostuse.MUMethod;
import mostuse.MUObject;

public class Nurse extends Employee
{
    private String department;
    private Float allowance;

    public void setDepartment(String department)
    {
        this.department = department.toLowerCase().trim();
    }

    public void setAllowance(Float allowance)
    {
        this.allowance = allowance;
    }

    @Override
    public void inputEmployeeInfo()
    {
        setEmployeeType(Byte.valueOf("1"));
        setId(MUMethod.inputStringAndValidate("nurse id", MUObject.nurseIdRegex));

        super.inputEmployeeInfo();

        setDepartment(MUMethod.inputStringAndValidate("department", MUObject.nurseDepartmentRegex));
        setAllowance(MUMethod.inputFloatAndValidate("allowance"));
    }

    @Override
    public String toString()
    {
        return super.toString().concat(department)
                .concat(" | ").concat(allowance.toString());
    }
}
