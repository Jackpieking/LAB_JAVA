package people;

import mostuse.MUMethod;
import mostuse.MUObject;

public class Employee implements Comparable<Employee>
{
    private String id;
    private String name;
    private String phone;
    private String email;
    private Byte employeeType;

    public void setId(String id)
    {
        this.id = id.trim();
    }

    public void setName(String name)
    {
        this.name = name.trim();
    }

    public void setPhone(String phone)
    {
        this.phone = phone.trim();
    }

    public void setEmail(String email)
    {
        this.email = email.trim();
    }

    public void setEmployeeType(Byte employeeType)
    {
        this.employeeType = employeeType;
    }

    public void inputEmployeeInfo()
    {
        setName(MUMethod.inputStringAndValidate("name", MUObject.nameRegex));
        setPhone(MUMethod.inputStringAndValidate("phone", MUObject.phoneRegex));
        setEmail(MUMethod.inputStringAndValidate("email", MUObject.emailRegex));
    }

    @Override
    public String toString()
    {
        return id.concat(" | ")
                .concat(name).concat(" | ")
                .concat(phone).concat(" | ")
                .concat(email).concat(" | ");
    }

    @Override
    public int compareTo(Employee employee)
    {
        return employeeType.compareTo(employee.employeeType);
    }
}
