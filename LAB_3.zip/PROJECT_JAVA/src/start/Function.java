package start;

import people.Doctor;
import people.Employee;
import people.Nurse;

import java.util.List;

class Function
{
    void createDoctorFunc(List<Employee> employees)
    {
        var doctor = new Doctor();

        doctor.inputEmployeeInfo();

        employees.add(doctor);

        System.out.println();
    }

    void createNurseFunc(List<Employee> employees)
    {
        var nurse = new Nurse();

        nurse.inputEmployeeInfo();

        employees.add(nurse);

        System.out.println();
    }

    void viewAllEmployeeInformation(List<Employee> employees)
    {
        if (employees.isEmpty())
        {
            System.out.printf("%nNo employees are found!!%n%n");
            return;
        }

        System.out.println();

        employees.sort(Employee::compareTo);

        if (employees.get(0) instanceof Doctor)
        {
            System.out.println("========Doctor======");
            for (var employee: employees)
            {
                if (employee instanceof Doctor doctor)
                {
                    System.out.println(doctor);
                }
                else
                {
                    break;
                }
            }
        }

        if (employees.get(employees.size() - 1) instanceof Nurse)
        {
            System.out.println("========Nurse======");
            for (int idx = employees.size() - 1; idx >= 0; idx--)
            {
                if (employees.get(idx) instanceof Nurse nurse)
                {
                    System.out.println(nurse);
                }
                else
                {
                    break;
                }
            }
        }

        System.out.println();
    }

    void exit()
    {
        System.exit(1);
    }
}
