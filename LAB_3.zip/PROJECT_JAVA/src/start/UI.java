package start;

class UI
{
    void printMenu()
    {
        System.out.println("WELCOME TO EMPLOYEE MANAGEMENT");
        System.out.printf("%24s%n", "1. Create Doctor");
        System.out.printf("%23s%n", "2. Create Nurse");
        System.out.printf("%42s%n", "3. View all employee's information");
        System.out.printf("%15s%n", "4. Exit");
    }
}
