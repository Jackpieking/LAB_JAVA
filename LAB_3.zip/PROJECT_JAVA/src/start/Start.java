package start;

import mostuse.*;
import people.Employee;

import java.util.ArrayList;
import java.util.List;

public class Start
{
    static List<Employee> employees = new ArrayList<>();

    public void start()
    {
        UI uiPrinter = new UI();
        Function function = new Function();

        while (true)
        {
            uiPrinter.printMenu();

            switch (MUMethod.inputIntegerAndValidate("your choice"))
            {
                case 1 -> function.createDoctorFunc(employees);
                case 2 -> function.createNurseFunc(employees);
                case 3 -> function.viewAllEmployeeInformation(employees);
                case 4 -> function.exit();
                default -> System.out.printf("%nOption not found!!%n%n");
            }
        }
    }
}
